import os

BOT_TOKEN = os.getenv("BOT_TOKEN", "8487130667:AAFWbQG-yhjkZHe-fyiS80duQppPUps2VZg")
BOT_NAME = "CINEMA_uz90_bot"
ADMINS = [int(x) for x in os.getenv("ADMINS", "5714788187").split(",")]
MOVIE_CHANNEL = int(os.getenv("MOVIE_CHANNEL", "-1003924104096"))

LIMIT = 10
PREMIUM_PRICE_1 = 15000
PREMIUM_PRICE_3 = 35000
PREMIUM_PRICE_12 = 65000
MOVIE_COST = 2
LIMIT_PRICE = 5000

PAYMENT_LINKS = {
    15000: "https://safopay.uz/pay/69a7b42d131a74590cc9aadf8b2d5dd8196a40c57d1e768616d9da3806b0b61f",
    35000: "https://safopay.uz/pay/d91d93b7f8cb3f5b5d1ed4f7086e622b2e39db7dbbf30063bab8cf3412a1",
    65000: "https://safopay.uz/pay/d91d93b7f8cb3f5b5d1ed4f7086e622b2e39db7dbbf30063bab8cf3412a1",
    5000: "https://safopay.uz/pay/d91d93b7f8cb3f5b5d1ed4f7086e622b2e39db7dbbf30063bab8cf3412a1"
}

ADMIN_USER = "@XONaction"
ADMIN_CARD = "4916990323171766"
ADMIN_CARD_NAME = "Matnazarov Shoxruhxon"

LOGO_PATH = "assets/logo.jpg"

TELEGRAM_CHANNELS = []
EXTERNAL_CHANNELS = []
